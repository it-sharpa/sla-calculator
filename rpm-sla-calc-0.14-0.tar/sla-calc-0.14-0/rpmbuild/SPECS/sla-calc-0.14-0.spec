# spec file for package sla-calc v.0-14-0
# rules v.1.0
#
# Copyright (c) 2026 'Eugene Lutin' <tylerfc@inbox.ru>
# The license for this file: Apache-2.0
Name:           sla-calc
Summary:        sla calculator
URL:            https://github.com/it-sharpa/sla-calculator
License:        Apache-2.0
Provides:       sla-calc
Version:        0.14
Release:        0%{?dist}
Source0:        %{SOURCE0}/
BuildArch:      x86_64
Conflicts:      sla-calc-universal
Requires:       bash
Requires:       glibc >= 2.24

%description
utility, for calculate time availability systems. sla-calc developing on C language

%install
rm -rf /root/rpmbuild/BUILDROOT/*
rm -rf /root/rpmbuild/RPMS/*/*
mkdir -p %{buildroot}/%{_exec_prefix}/bin/ %{buildroot}/%{_datarootdir}/man/man1/
install -Dpm 0555 /root/rpmbuild/%{_exec_prefix}/bin/%{name} %{buildroot}/%{_exec_prefix}/bin/%{name}
install -Dpm 0444 /root/rpmbuild/%{_datarootdir}/man/man1/%{name}.1.gz %{buildroot}/%{_datarootdir}/man/man1/%{name}.1.gz

%files
%{_exec_prefix}/bin/%{name}
%doc %{_datarootdir}/man/man1/%{name}.1.gz

%changelog
* Wed Jul 08 2026 root - 0:0.14-0
- the code has been reworked, taking into account suggestions from commit #1 (github, Nyvyme)
- added strict check arguments value

* Sun Jun 21 2026 root - 0:0.13-9
- added minimum functional SLA calculator
